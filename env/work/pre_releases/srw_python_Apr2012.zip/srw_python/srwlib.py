#############################################################################
# SRWLIB for Python v 0.051
#############################################################################

from __future__ import print_function #Python 2.7 compatibility
import srwlpy as srwl
from array import *

#****************************************************************************
# Python Classes
#****************************************************************************
class SRWLParticle:
    """Charged Particle"""
    x = 0 #instant coordinates [m]
    y = 0
    z = 0
    xp = 0 #instant transverse velocity components: btx = vx/c, bty = vy/c (angles for relativistic particle)
    yp = 0
    gamma = 1 #relative energy
    relE0 = 1 #rest mass (energy) in units of electron rest mass: =1 for electron, =1836.1526988 (=938.272013/0.510998902) for proton
    nq = -1; #charge of the particle related to absolute value of electron charge: =-1 for electron, =1 for positron and for proton
    def __init__(self, _x=0, _y=0, _z=0, _xp=0, _yp=0, _gamma=1, _relE0=1, _nq=-1):
        self.x = _x
        self.y = _y
        self.z = _z
        self.xp = _xp
        self.yp = _yp
        self.gamma = _gamma
        self.relE0 = _relE0
        self.nq = _nq

#****************************************************************************
class SRWLPartBeam:
    """Particle Beam"""
    Iavg = 0 #average current [A]
    nPart = 0 #number of electrons (in a bunch)
    partStatMom1 = SRWLParticle() #particle type and 1st order statistical moments
    arStatMom2 = array('d', [0]*21) #2nd order statistical moments
    def __init__(self, _Iavg=0, _nPart=0, _partStatMom1=SRWLParticle(), _arStatMom2=array('d', [0]*21)):
        self.Iavg = _Iavg
        self.nPart = _nPart
        self.partStatMom1 = _partStatMom1
        self.arStatMom2 = _arStatMom2

#****************************************************************************
class SRWLMagFld:
    """Magnetic Field (base class)"""
    #tp = '' #could be added to facilitate type cast if Python 2.x is used(?)
    
class SRWLMagFld3D(SRWLMagFld):
    """Magnetic Field: Arbitrary 3D"""
    arBx = array('d') #3D magnetic field component arrays [T]
    arBy = array('d')
    arBz = array('d')
    nx = 0 #numbers of magnetic field data points in the horizontal, vertical and longitudinal directions
    ny = 0
    nz = 0
    rx = 0 #ranges of horizontal, vertical and longitudinal coordinated for which the field is defined [m]
    ry = 0
    rz = 0
    arX = array('d') #optional arrays of transverse and longitudinal coordinates of an irregular 3D mesh (if these pointers are not zero, rx, ry, rz will be ignored; to define a regular (constant-step) 3D mesh, these pointers should be set to zero)
    arY = array('d')
    arZ = array('d')
    nRep = 1 #"number of periods", i.e. number of times the field is "repeated" in the longitudinal direction
    interp = 1 #interpolation method to use (e.g. for trajectory calculation): 1- bi-linear (3D), 2- (bi-)quadratic (3D), 3- (bi-)cubic (3D)
    #tp = 'a' #could be added to facilitate type cast if Python 2.x is used(?)
    def __init__(self, _arBx=array('d'), _arBy=array('d'), _arBz=array('d'), _nx=0, _ny=0, _nz=0, _rx=0, _ry=0, _rz=0, _nRep=1, _interp=1):
        self.arBx = _arBx
        self.arBy = _arBy
        self.arBz = _arBz
        self.nx = _nx
        self.ny = _ny
        self.nz = _nz
        self.rx = _rx
        self.ry = _ry
        self.rz = _rz
        self.nRep = _nRep
        self.interp = _interp

class SRWLMagFldM(SRWLMagFld):
    """Magnetic Field: Multipole Magnet"""
    G = 0 #field parameter: [T] for dipole, [T/m] for quadrupole (negative means defocusing for x), [T/m^2] for sextupole, [T/m^3] for octupole
    m = 2 #multipole order: 1 for dipole, 2 for quadrupoole, 3 for sextupole, 4 for octupole
    n_or_s = 'n' #normal ('n') or skew ('s')
    Leff = 0 #effective length [m]
    Ledge = 0 #"soft" edge length for field variation from 10% to 90% [m]; G/(1 + ((z-zc)/d)^2)^2 fringe field dependence is assumed
    #tp = 'm' #could be added to facilitate type cast if Python 2.x is used(?)
    def __init__(self, _G=0, _m=2, _n_or_s='n', _Leff=0, _Ledge=0):
        self.G = _G
        self.m = _m
        self.n_or_s = _n_or_s
        self.Leff = _Leff
        self.Ledge = _Ledge

class SRWLMagFldS(SRWLMagFld):
    """Magnetic Field: Solenoid"""
    B = 0 #magnetic field [T]
    Leff = 0 #effective length [m]
    #tp = 's' #could be added to facilitate type cast if Python 2.x is used(?)
    def __init__(self, _B=0, _Leff=0):
        self.B = _B
        self.Leff = _Leff

class SRWLMagFldH(SRWLMagFld):
    """Magnetic Field: Undulator Harmonic"""
    n = 1 #harmonic number
    h_or_v = 'v' #magnetic field plane: horzontal ('h') or vertical ('v')
    B = 0 #magnetic field amplitude [T]
    ph = 0 #phase [rad]
    s = 1 #symmetry vs longitudinal position: 1 - symmetric (B ~ cos(2*Pi*n*z/per + ph)) , -1 - anti-symmetric (B ~ sin(2*Pi*n*z/per + ph))
    a = 1 #coefficient for transverse depenednce: B*cosh(2*Pi*n*a*y/per)*cos(2*Pi*n*z/per + ph)
    #tp = 'h' #could be added to facilitate type cast if Python 2.x is used(?)
    def __init__(self, _n=1, _h_or_v='v', _B=0, _ph=0, _s=1, _a=1):
        self.n = _n
        self.h_or_v = _h_or_v
        self.B = _B
        self.ph = _ph
        self.s = _s
        self.a = _a

class SRWLMagFldU(SRWLMagFld):
    """Magnetic Field: Undulator"""
    arHarm = [] #array of field harmonics
    per = 0 #period length [m]
    nPer = 0 #number of periods (will be rounded to integer)
    #tp = 'u' #could be added to facilitate type cast if Python 2.x is used(?)
    def __init__(self, _arHarm=[], _per=0, _nPer=0):
        self.arHarm = _arHarm
        self.per = _per
        self.nPer = _nPer
    def allocate(self, _nHarm):
        self.arHarm = [SRWLMagFldH()]*_nHarm

class SRWLMagFldC(SRWLMagFld):
    """Magnetic Field: Container"""
    arMagFld = [] #magnetic field structures array
    arXc = array('d') #horizontal center positions of magnetic field elements in arMagFld array
    arYc = array('d') #vertical center positions of magnetic field elements in arMagFld array
    arZc = array('d') #longitudinal center positions of magnetic field elements in arMagFld array
    #tp = 'c' #could be added to facilitate type cast if Python 2.x is used(?)
    def __init__(self, _arMagFld=[], _arXc=array('d'), _arYc=array('d'), _arZc=array('d')):
        self.arMagFld = _arMagFld
        self.arXc = _arXc
        self.arYc = _arYc
        self.arZc = _arZc
    def allocate(self, _nElem):
        self.arMagFld = [SRWLMagFld()]*_nElem
        self.arXc = array('d', [0]*_nElem)
        self.arYc = array('d', [0]*_nElem)
        self.arZc = array('d', [0]*_nElem)

#****************************************************************************
class SRWLPrtTrj:
    """Charged Particle Trajectory"""
    arX = array('d') #arrays of horizontal, vertical and longitudinal positions [m] and relative velocities
    arXp = array('d')
    arY = array('d')
    arYp = array('d')
    arZ = array('d')
    arZp = array('d')
    np = 0 #number of trajectory points
    ctStart = 0 #start and end values of independent variable (c*t) for which the trajectory should be (/is) calculated (is constant step enough?)
    ctEnd = 0
    partInitCond = SRWLParticle() #particle type and initial conditions for which the trajectory should be (/is) calculated
    def __init__(self, _arX=array('d'), _arXp=array('d'), _arY=array('d'), _arYp=array('d'), _arZ=array('d'), _arZp=array('d'), _np=0, _ctStart=0, _ctEnd=0, _partInitCond=SRWLParticle()):
        self.arX = _arX
        self.arXp = _arXp
        self.arY = _arY
        self.arYp = _arYp
        self.arZ = _arZ
        self.arZp = _arZp
        self.np = _np
        self.ctStart = _ctStart
        self.ctEnd = _ctEnd
        self.partInitCond = _partInitCond
    def allocate(self, _np):
        _np = int(_np)
        self.arX = array('d', [0]*_np)
        self.arXp = array('d', [0]*_np)
        self.arY = array('d', [0]*_np)
        self.arYp = array('d', [0]*_np)
        self.arZ = array('d', [0]*_np)
        self.arZp = array('d', [0]*_np)
        self.np = _np

#****************************************************************************
class SRWLKickM:
    """Kick Matrix (for fast trajectory calculation)"""
    arKickMx = array('d') #horizontal and vertucal kick-matrices tabulated of the same transverse grid (vs x and y)
    arKickMy = array('d')
    order = 2 #kick order: 1- first order (in this case kick matrix data is assumed to be in [T*m]), 2- second order (kick matrix data is assumed to be in [T^2*m^2])
    nx = 0 #nx, ny are numbers of points in kick matrices in horizontal and vertical directions, nz is number of steps in longitudinal direction
    ny = 0
    nz = 0
    rx = 0 #rx, ry are ranges covered by kick matrices in horizontal and vertical directions, rz is extension in longitudinal direction [m]
    ry = 0
    rz = 0
    x = 0 #horizontal, vertical and longitudinal coordinates of center point [m]
    y = 0
    z = 0
    def __init__(self, _arKickMx=array('d'), _arKickMy=array('d'), _order=2, _nx=0, _ny=0, _nz=0, _rx=0, _ry=0, _rz=0, _x=0, _y=0, _z=0):
        self.arKickMx = _arKickMx
        self.arKickMy = _arKickMy
        self.order = _order
        self.nx = _nx
        self.ny = _ny
        self.nz = _nz
        self.rx = _rx
        self.ry = _ry
        self.rz = _rz
        self.x = _x
        self.y = _y
        self.z = _z

#****************************************************************************
class SRWLGsnBm:
    """Gaussian Beam"""
    x = 0 #average coordinates at waist [m]
    y = 0
    z = 0
    xp = 0 #average angles at waist [rad]
    yp = 0
    avgPhotEn = 1 #average photon energy [eV]
    pulseEn = 1 #energy per pulse [J]
    repRate = 1 #rep. rate [Hz]
    polar = 1 #polarization: 1- lin. hor., 2- lin. vert., 3- lin. 45 deg., 4- lin.135 deg., 5- circ. right, 6- circ. left
    sigX = 10e-06 #rms beam sizes vs horizontal, vertical position [m] and time [s] at waist (for intensity)
    sigY = 10e-06
    sigT = 1e-15 #rms pulse duration [s] (for intensity)
    mx = 0 #transverse Gauss-Hermite mode orders
    my = 0
    def __init__(self, _x=0, _y=0, _z=0, _xp=0, _yp=0, _avgPhotEn=1, _pulseEn=1, _repRate=1, _polar=1, _sigX=10e-06, _sigY=10e-06, _sigT=1e-15, _mx=0, _my=0):
        self.x = _x
        self.y = _y
        self.z = _z
        self.xp = _xp
        self.yp = _yp
        self.avgPhotEn = _avgPhotEn
        self.pulseEn = _pulseEn
        self.repRate = _repRate
        self.polar = _polar
        self.sigX = _sigX
        self.sigY = _sigY
        self.sigT = _sigT
        self.mx = _mx
        self.my = _my

#****************************************************************************
class SRWLWfr:
    """Radiation Wavefront (Electric Field)"""
    arEx = 0 #array('f', [0]*2) #horizontal complex electric field component array; NOTE: only 'f' (float) is supported for the moment (Jan. 2011)
    arEy = 0 #array('f', [0]*2) #vertical complex electric field component array
    eStart = 0 #initial and final values of photon energy (/time), horizontal and vertical positions
    eFin = 0
    xStart = 0
    xFin = 0
    yStart = 0
    yFin = 0
    zStart = 0
    ne = 0 #numbers of points vs photon energy, horizontal and vertical positions
    nx = 0
    ny = 0
    Rx = 0 #instant wavefront radii
    Ry = 0 
    dRx = 0 #error of wavefront radii
    dRy = 0
    xc = 0 #instant transverse coordinates of wavefront instant "source center"
    yc = 0
    avgPhotEn = 0 #average photon energy for time-domain simulations    
    presCA = 0 #presentation/domain: 0- coordinates, 1- angles
    presFT = 0 #presentation/domain: 0- frequency (photon energy), 1- time
    numTypeElFld = 'f' #electric field numerical type: 'f' (float) or 'd' (double)
    unitElFld = 1 #electric field units: 0- arbitrary, 1- sqrt(Phot/s/0.1%bw/mm^2) ?
    partBeam = SRWLPartBeam() #particle beam source; strictly speaking, it should be just SRWLParticle; however, "multi-electron" information can appear useful for those cases when "multi-electron intensity" can be deduced from the "single-electron" one by convolution
    arElecPropMatr = array('d', [0]*20) #effective 1st order "propagation matrix" for electron beam parameters
    arMomX = array('d', [0]*11) #statistical moments (of Wigner distribution); to check the exact number of moments required
    arMomY = array('d', [0]*11)
    arWfrAuxData = array('d', [0]*30) #array of auxiliary wavefront data
    def __init__(self, _arEx=0, _arEy=0, _typeE='f', _eStart=0, _eFin=0, _ne=1, _xStart=0, _xFin=0, _nx=1, _yStart=0, _yFin=0, _ny=1, _partBeam=SRWLPartBeam()):
        self.arEx = _arEx
        self.arEy = _arEy
        self.numTypeElFld = _typeE
        self.eStart = _eStart
        self.eFin = _eFin
        self.ne = _ne
        self.xStart = _xStart
        self.xFin = _xFin
        self.nx = _nx
        self.yStart = _yStart
        self.yFin = _yFin
        self.ny = _ny
        self.partBeam = _partBeam
        self.arMomX = array('d', [0]*11*_ne)
        self.arMomY = array('d', [0]*11*_ne)
    def allocate(self, _ne, _nx, _ny, EXNeeded=1, EYNeeded=1, typeE='f'):
        print('') #debugging
        print('          (re-)allocating: old point numbers: ne=',self.ne,' nx=',self.nx,' ny=',self.ny,' type:',self.numTypeElFld)
        print('                           new point numbers: ne=',_ne,' nx=',_nx,' ny=',_ny,' type:',typeE)
        nTot = 2*_ne*_nx*_ny #array length to store one component of complex electric field
        nMom = 11*_ne
        if EXNeeded:
            #print('          trying to (re-)allocate Ex ... ', end='')  
            del self.arEx
            self.arEx = array(typeE, [0]*nTot)
            #print('done')           
            if len(self.arMomX) != nMom:
                del self.arMomX
                self.arMomX = array('d', [0]*nMom)
        if EYNeeded:
            #print('          trying to (re-)allocate Ey ... ', end='')  
            #del self.arEy
            self.arEy = array(typeE, [0]*nTot)
            #print('done')
            if len(self.arMomY) != nMom:
                del self.arMomY
                self.arMomY = array('d', [0]*nMom)
        self.numTypeElFld = typeE
        self.ne = _ne
        self.nx = _nx
        self.ny = _ny

#****************************************************************************
class SRWLStokes:
    """Radiation Stokes Parameters"""
    arS0 = 0 #array('f', [0]*1) #s0 Stokes parameter array; NOTE: only 'f' (float) is supported for the moment (Jan. 2012)
    arS1 = 0 #array('f', [0]*1) #s1 Stokes parameter array
    arS2 = 0 #array('f', [0]*1) #s2 Stokes parameter array
    arS3 = 0 #array('f', [0]*1) #s3 Stokes parameter array
    eStart = 0 #initial and final values of photon energy (/time), horizontal and vertical positions
    eFin = 0
    xStart = 0
    xFin = 0
    yStart = 0
    yFin = 0
    zStart = 0
    ne = 0 #numbers of points vs photon energy, horizontal and vertical positions
    nx = 0
    ny = 0
    avgPhotEn = 0 #average photon energy for time-domain simulations    
    presCA = 0 #presentation/domain: 0- coordinates, 1- angles
    presFT = 0 #presentation/domain: 0- frequency (photon energy), 1- time
    numTypeStokes = 'f' #electric field numerical type: 'f' (float) or 'd' (double)
    unitStokes = 1 #electric field units: 0- arbitrary, 1- Phot/s/0.1%bw/mm^2 ?
    def __init__(self, _arS0=0, _arS1=0, _arS2=0, _arS3=0, _typeStokes='f', _eStart=0, _eFin=0, _ne=1, _xStart=0, _xFin=0, _nx=1, _yStart=0, _yFin=0, _ny=1):
        self.arS0 = _arS0
        self.arS1 = _arS1
        self.arS2 = _arS2
        self.arS3 = _arS3
        self.numTypeStokes = _typeStokes
        self.eStart = _eStart
        self.eFin = _eFin
        self.ne = _ne
        self.xStart = _xStart
        self.xFin = _xFin
        self.nx = _nx
        self.yStart = _yStart
        self.yFin = _yFin
        self.ny = _ny
    def allocate(self, _ne, _nx, _ny, s0needed=1, s1needed=1, s2needed=1, s3needed=1, _typeStokes='f'):
        print('') #debugging
        print('          (re-)allocating: old point numbers: ne=',self.ne,' nx=',self.nx,' ny=',self.ny,' type:',self.numTypeStokes)
        print('                           new point numbers: ne=',_ne,' nx=',_nx,' ny=',_ny,' type:',_typeStokes)
        nTot = _ne*_nx*_ny #array length to one Stokes component
        if s0needed:
            del self.arS0
            self.arS0 = array(_typeStokes, [0]*nTot)
        if s1needed:
            del self.arS1
            self.arS1 = array(_typeStokes, [0]*nTot)
        if s2needed:
            del self.arS2
            self.arS2 = array(_typeStokes, [0]*nTot)
        if s3needed:
            del self.arS3
            self.arS3 = array(_typeStokes, [0]*nTot)
        self.numTypeStokes = _typeStokes
        self.ne = _ne
        self.nx = _nx
        self.ny = _ny

#****************************************************************************
class SRWLOpt:
    """Optical Element (base class)"""

class SRWLOptD(SRWLOpt):
    """Optical Element: Drift Space"""
    L = 0 #[m]
    def __init__(self, _L=0):
        self.L = _L

class SRWLOptA(SRWLOpt):
    """Optical Element: Aperture / Obstacle"""
    shape = 'r' #'r' for rectangular, 'c' for circular
    ap_or_ob = 'a' #'a' for aperture, 'o' for obstacle
    Dx = 0 #transverse dimensions [m]; in case of circular aperture, only Dx is used for diameter
    Dy = 0
    x = 0 #transverse coordinates of center [m]
    y = 0
    def __init__(self, _shape='r', _ap_or_ob='a', _Dx=0, _Dy=0, _x=0, _y=0):
        #if (_shape == 'r') or (_shape == 'c'):
        self.shape = _shape
        #else:   
        self.ap_or_ob = _ap_or_ob
        self.Dx = _Dx
        self.Dy = _Dy
        self.x = _x
        self.y = _y

class SRWLOptL(SRWLOpt):
    """Optical Element: Thin Lens"""
    Fx = 1e+23 #focal lengths [m]
    Fy = 1e+23
    x = 0 #transverse coordinates of center [m]
    y = 0
    def __init__(self, _Fx=1e+23, _Fy=1e+23, _x=0, _y=0):
        self.Fx = _Fx
        self.Fy = _Fy
        self.x = _x
        self.y = _y

class SRWLOptZP(SRWLOpt):
    """Optical Element: Thin Lens"""
    nZones = 100 #total number of zones
    rn = 0.1e-03 #auter zone radius [m]
    thick = 10e-06 #thickness [m]
    delta1 = 1e-06 #refractuve index decrements of the "main" and "complementary" materials
    delta2 = 0
    atLen1 = 0.1 #attenuation length [m] of the "main" and "complementary" materials
    atLen2 = 1e-06
    x = 0 #transverse coordinates of center [m]
    y = 0
    def __init__(self, _nZones=100, _rn=0.1e-03, _thick=10e-06, _delta1=1e-06, _atLen1=0.1, _delta2=0, _atLen2=1e-06, _x=0, _y=0):
        self.nZones = _nZones
        self.rn = _rn
        self.thick = _thick
        self.delta1 = _delta1
        self.delta2 = _delta2
        self.atLen1 = _atLen1
        self.atLen2 = _atLen2
        self.x = _x
        self.y = _y

class SRWLOptWG(SRWLOpt):
    """Optical Element: Waveguide"""
    L = 1 #length [m]
    Dx = 10e-03 #transverse dimensions [m]
    Dy = 10e-03
    x = 0 #transverse coordinates of center [m]
    y = 0
    def __init__(self, _L=1, _Dx=10e-03, _Dy=10e-03, _x=0, _y=0):
        self.L = _L
        self.Dx = _Dx
        self.Dy = _Dy
        self.x = _x
        self.y = _y

class SRWLOptG(SRWLOpt):
    """Optical Element: Grating (planar)"""
    grDen = 100 #groove density [lines/mm]
    disPl = 'v' #dispersion plane: 'x' ('h') or 'y' ('v')
    ang = 0.7854 #angle between optical axis and grating plane [rad]
    m = 1 #output order
    refl = 1 #average reflectivity (with resp. to intensity)
    def __init__(self, _grDen=100, _disPl='v', _ang=0.7854, _m=1, _refl=1):
        self.grDen = _grDen
        self.disPl = _disPl
        self.ang = _ang
        self.m = _m
        self.refl = _refl

class SRWLOptT(SRWLOpt):
    """Optical Element: Transmission (generic)"""
    arTr = array('d') #complex C-aligned data array (of 2*nx*ny length) storing amplitude transmission and optical path difference as function of transverse position
    #dependence vs Photon Energy to be introduced!
    nx = 100 #numbers of transmission data points in the horizontal and vertical directions
    ny = 100
    rx = 1e-03 #ranges of horizontal and vertical coordinates [m] for which the transmission is defined
    ry = 1e-03
    extTr = 0 #0- transmission outside the grid/mesh is zero; 1- it is same as on boundary
    Fx = 1e+23 #estimated focal lengths [m]
    Fy = 1e+23
    x = 0 #transverse coordinates of center [m]
    y = 0
    def allocate(self, _nx, _ny):
        self.nx = _nx
        self.ny = _ny
        nTot = 2*_nx*_ny #total array length to store amplitude transmission and optical path difference
        self.arTr = array('d', [0]*nTot)
    def __init__(self, _nx=1, _ny=1, _rx=1e-03, _ry=1e-03, _arTr=array('d'), _extTr=0, _Fx=1e+23, _Fy=1e+23, _x=0, _y=0):
        self.arTr = _arTr
        self.nx = _nx
        self.ny = _ny
        self.rx = _rx
        self.ry = _ry
        self.extTr = _extTr
        self.Fx = _Fx
        self.Fy = _Fy
        self.x = _x
        self.y = _y
        if((len(_arTr) <= 0) and (_nx*_ny > 0)):
            self.allocate(_nx, _ny)

class SRWLOptC(SRWLOpt):
    """Optical Element: Container"""
    arOpt = [] #optical element structures array
    arProp = [] #list of lists of propagation parameters to be used for individual optical elements
    def __init__(self, _arOpt=[], _arProp=[]):
        self.arOpt = _arOpt
        self.arProp = _arProp
    def allocate(self, _nElem):
        self.arOpt = [SRWLOpt()]*_nElem
        self.arProp = [[0]*12]*_nElem

#****************************************************************************
