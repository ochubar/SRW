Comments to "SRWLIB" v. 0.05x (November 2011)
================================================

- "srwlpy.pyd", "srwlpy.so" are SRW Python bindings (shared libraries) compiled for 64-bit Windows and Linux respectively; the "default" versions are made for the use with Python 3.2, however, Python 2.7 versions are also available: ../srw_python/lib/srwlpy_x64_py27.pyd (for Windows). Note that 32-bit versions for Windows and for Linux are also available: ../srw_python/lib/srwlpy_win32.pyd, ../srw_python/lib/srwlpy_i686_py32.so. To use these versions (with 32-bit Python 3.2!) - rename the corresponding file to "srwlpy.pyd" or "srwlpy.so" and place it into the main "srw_python" directory instead of the existing "srwlpy.pyd" (or ".so") file.

- "srwlib.py", "SRWLIB_Example*.py" - SRWLIB Python module and example files. 

- "lib/srw*.lib", "lib/libsrw_x86_64.a": static SRW libraries compiled for 32- (srw_win32.lib) and 64-bit (srw_x64.lib) Windows and 64-bit Linux (libsrw_x86_64.a).

- "srwlclient*.exe": 32- (srwlclient32.exe) and 64-bit (srwlclient64.exe) simple test C client application for Windows, illustrating the use of SRWLIB. It runs different examples (essentially the same as "SRWLIB_Example*.py" scripts); the source file is: srw_python/src/srwlclient.cpp.

- srw_python/src/srwlib.h is the header file of SRW C API (it defines some structures and declares functions of SRWLib).

