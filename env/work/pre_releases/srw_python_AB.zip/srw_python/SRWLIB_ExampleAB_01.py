# -*- coding: utf-8 -*-
#############################################################################
# SRWLIB Example: Simulating emission and propagation of partially-coherent undulator radiation at BL43 (SPring8)
# v 0.01
#############################################################################

from __future__ import print_function #Python 2.7 compatibility
from srwlib import *
import math
import os
import sys
import time

print('SRWLIB Python Example:')
print('!!!!!Under testing!!!!!')
print('Simulating emission and propagation of partially-coherent undulator radiation at BL43 (SPring8)')
print('')
print('First, single-electron UR wavefront at a fixed photon energy is calculated and propagated through the optical scheme. ', end='')
print('After this, calculation of partially-coherent UR from entire electron beam is started as a loop over "macro-electrons", using "srwl_wfr_emit_prop_multi_e" function. ', end='')
print('This function can run either in "normal" sequential mode, or in parallel mode under "mpi4py".', end='')
print('For this, an MPI2 package and the "mpi4py" Python package have to be installed and configured, and this example has to be started e.g. as:')
print('    mpiexec -n 5 python SRWLIB_ExampleAB_01.py')
print('For more information on parallel calculations under "mpi4py" please see documentation to the "mpi4py" and MPI.')
print('Note that the long-lasting partially-coherent UR calculation saves from time to time instant average intensity to an ASCII file, ', end='')
print('so the execution of the long loop over "macro-electrons" can be aborted after some time without the danger that all results will be lost.')
print('')

#********************** Auxiliary Functions
#Write tabulated resulting Trajectory data to ASCII file:
def AuxSaveTrajData(traj, filePath):
    f = open(filePath, 'w')
    resStr = '#ct [m], X [m], BetaX [rad], Y [m], BetaY [rad], Z [m], BetaZ [rad]'
    if(hasattr(traj, 'arBx')):
        resStr += ', Bx [T]'
    if(hasattr(traj, 'arBy')):
        resStr += ', By [T]'
    if(hasattr(traj, 'arBz')):
        resStr += ', Bz [T]'
    f.write(resStr + '\n')
    ctStep = 0
    if traj.np > 0:
        ctStep = (traj.ctEnd - traj.ctStart)/(traj.np - 1)
    ct = traj.ctStart
    for i in range(traj.np):
        resStr = str(ct) + '\t' + repr(traj.arX[i]) + '\t' + repr(traj.arXp[i]) + '\t' + repr(traj.arY[i]) + '\t' + repr(traj.arYp[i]) + '\t' + repr(traj.arZ[i]) + '\t' + repr(traj.arZp[i])
        if(hasattr(traj, 'arBx')):
            resStr += '\t' + repr(traj.arBx[i])
        if(hasattr(traj, 'arBy')):
            resStr += '\t' + repr(traj.arBy[i])
        if(hasattr(traj, 'arBz')):
            resStr += '\t' + repr(traj.arBz[i])
        f.write(resStr + '\n')        
        ct += ctStep
    f.close()


#Read data comumns from ASCII file:
def AuxReadInDataColumns(filePath, nCol, strSep, nRowsToSkip):
    f = open(filePath, 'r')
    resCols = []
    for iCol in range(nCol):
        resCols.append([])
    iRow = 0
    curLine = f.readline()
    while len(curLine) > 0:
        if(iRow >= nRowsToSkip):
            curLineParts = curLine.split(strSep)
            for iCol in range(nCol):
                if(iCol < len(curLineParts)):
                    resCols[iCol].append(float(curLineParts[iCol]))
        iRow += 1
        curLine = f.readline()
    f.close()
    return resCols #attn: returns lists, not arrays!

#Write Optical Transmission characteristic data to ASCII file:
def AuxSaveOpTransmData(optTr, t, filePath):
    f = open(filePath, 'w')
    f.write('#C-aligned optical Transmission characteristic (inner loop is vs horizontal position, outer loop vs vertical position)\n')
    f.write('#' + repr(optTr.mesh.eStart) + ' #Initial Photon Energy [eV]\n')
    f.write('#' + repr(optTr.mesh.eFin) + ' #Final Photon Energy [eV]\n')
    f.write('#' + repr(optTr.mesh.ne) + ' #Number of points vs Photon Energy\n')
    f.write('#' + repr(optTr.mesh.xStart) + ' #Initial Horizontal Position [m]\n')
    f.write('#' + repr(optTr.mesh.xFin) + ' #Final Horizontal Position [m]\n')
    f.write('#' + repr(optTr.mesh.nx) + ' #Number of points vs Horizontal Position\n')
    f.write('#' + repr(optTr.mesh.yStart) + ' #Initial Vertical Position [m]\n')
    f.write('#' + repr(optTr.mesh.yFin) + ' #Final Vertical Position [m]\n')
    f.write('#' + repr(optTr.mesh.ny) + ' #Number of points vs Vertical Position\n')
    neLoc = 1
    if(optTr.mesh.ne > 1):
        neLoc = optTr.mesh.ne
    for i in range(neLoc*optTr.mesh.nx*optTr.mesh.ny): #write all data into one column using "C-alignment" as a "flat" 1D array
        tr = 0
        if((t == 1) or (t == 2)): #amplitude or intensity transmission
            tr = optTr.arTr[i*2]
            if(t == 2): #intensity transmission
                tr *= tr
        else: #optical path difference
            tr = optTr.arTr[i*2 + 1]
        f.write(' ' + repr(tr) + '\n')
    f.close()

#Setup Transmission optical element with 1D heght profile data
def AuxTransmAddSurfHeightProfile(optSlopeErr, heightProfData, dim, ang):
    argHeightProfData = heightProfData[0]
    valHeightProfData = heightProfData[1]
    sinAng = math.sin(ang)
    npData = len(heightProfData[0])
    
    auxMesh = optSlopeErr.mesh
    xStep = (auxMesh.xFin - auxMesh.xStart)/(auxMesh.nx - 1)
    yStep = (auxMesh.yFin - auxMesh.yStart)/(auxMesh.ny - 1)

    y = auxMesh.yStart
    hApprox = 0
    ipStart = 0
    for iy in range(auxMesh.ny):
        if('y' in dim):
            hApprox = 0
            y1 = argHeightProfData[ipStart]*sinAng
            for i in range(ipStart + 1, npData):
                y2 = argHeightProfData[i]*sinAng
                if((y1 <= y) and (y < y2)):
                    hApprox = ((valHeightProfData[i] - valHeightProfData[i-1])/((argHeightProfData[i] - argHeightProfData[i-1])*sinAng))*(y - y1) + valHeightProfData[i-1]
                    #print(ipStart, i, iy, y1, y, y2, argHeightProfData[i-1], argHeightProfData[i], valHeightProfData[i-1], valHeightProfData[i], hApprox)
                    ipStart = i - 1
                    break
                y1 = y2

        x = auxMesh.xStart
        for ix in range(auxMesh.nx):
            if('x' in dim):
                if(ix == 0): ipStart = 0
                hApprox = 0
                x1 = argHeightProfData[ipStart]*sinAng
                for i in range(ipStart + 1, npData):
                    x2 = argHeightProfData[i]*sinAng
                    if((x1 <= x) and (x < x2)):
                        hApprox = ((valHeightProfData[i] - valHeightProfData[i-1])/((argHeightProfData[i] - argHeightProfData[i-1])*sinAng))*(x - x1) + valHeightProfData[i-1]
                        ipStart = i - 1
                        break
                    x1 = x2
            ofst = 2*ix + (2*auxMesh.nx)*iy

            optSlopeErr.arTr[ofst] = 1. #Amplitude Transmission
            optSlopeErr.arTr[ofst + 1] = 0. #Optical Path Difference
            if(hApprox != 0):
                optSlopeErr.arTr[ofst + 1] = -2*sinAng*hApprox #Optical Path Difference (to check sign!)
                #print(ix, iy, optSlopeErr.arTr[ofst + 1])
            x += xStep
        y += yStep

#********************** Data Folder and File Names:
strDataFolderName = 'data_example_AB' #example data sub-folder name
strMirSurfHeightInFileName = 'no_coat_with_Cu.dat' #input file name for mirror surface height
strMirOptPathDifOutFileName = 'res_opt_path_dif_er_m1.dat' #file name for (output) mirror optical path difference 
strTrajOutFileName = 'res_cen_elec_traj.dat' #file name for central electron trajectory
strIntSE_OutFileName = 'res_int0_se.dat' #file name for output initial single-electron SR intensity data
strIntPropSE_OutFileName = 'res_int1_se.dat' #file name for output propagated single-electron SR intensity data
strIntPropME_OutFileName = 'res_int1_me.dat' #file name for output propagated multi-electron SR intensity data

#********************** Undulator
numPer = 263.5 #Number of ID Periods (without counting for terminations
undPer = 0.019 #Period Length [m]
By = 0.547022 #Peak Vertical field [T]
phBy = 0 #Initial Phase of the Vertical field component
sBy =  1 #Symmetry of the Vertical field component vs Longitudinal position
xcID = 0 #Transverse Coordinates of Undulator Center [m]
ycID = 0
zcID = 0 #Longitudinal Coordinate of Undulator Center [m]

und = SRWLMagFldU([SRWLMagFldH(1, 'v', By, phBy, sBy, 1)], undPer, numPer) #Planar Undulator
magFldCnt = SRWLMagFldC([und], array('d', [xcID]), array('d', [ycID]), array('d', [zcID])) #Container of all Field Elements

#********************** Electron Beam
elecBeam = SRWLPartBeam()
elecBeam.Iavg = 0.1 #Average Current [A]
elecBeam.partStatMom1.x = 0. #Initial Transverse Coordinates 
elecBeam.partStatMom1.y = 0. #-0.00025
elecBeam.partStatMom1.z = 0. #-0.5*undPer*(numPer + 5) #Initial Longitudinal Coordinate (set before the ID)
#Note: setting elecBeam.partStatMom1.z = 0. (i.e. in the middle of undulator) may lead to trajectory tilt
#it may be safer to set it before the undulator; however, 2nd order statistical moments need the "translated" to that point
elecBeam.partStatMom1.xp = 0. #Initial Relative Transverse Velocities
elecBeam.partStatMom1.yp = 0.
elecBeam.partStatMom1.gamma = 8./0.51099890221e-03 #Relative Energy
#2nd order statistical moments (in center of undulator)
elecBeam.arStatMom2[0] = (263.01e-06)**2 #<(x-x0)^2>
elecBeam.arStatMom2[1] = 0
elecBeam.arStatMom2[2] = (13.7295e-06)**2 #<(x'-x'0)^2>
elecBeam.arStatMom2[3] = (4.11886e-06)**2 #<(y-y0)^2>
elecBeam.arStatMom2[4] = 0
elecBeam.arStatMom2[5] = (1.64754e-06)**2 #<(y'-y'0)^2>
elecBeam.arStatMom2[10] = (1.e-03)**2 #<(E-E0)^2>/E0^2

#********************** Precision Parameters for SR calculation
meth = 1 #SR calculation method: 0- "manual", 1- "auto-undulator", 2- "auto-wiggler"
relPrec = 0.01 #relative precision
zStartInteg = 0 #longitudinal position to start integration (effective if < zEndInteg)
zEndInteg = 0 #longitudinal position to finish integration (effective if > zStartInteg)
npTraj = 100000 #Number of points for trajectory calculation 
useTermin = 1 #Use "terminating terms" (i.e. asymptotic expansions at zStartInteg and zEndInteg) or not (1 or 0 respectively)
sampFactNxNyForProp = 0.3 #sampling factor for adjusting nx, ny (effective if > 0)
arPrecParSpec = [meth, relPrec, zStartInteg, zEndInteg, npTraj, useTermin, sampFactNxNyForProp]

#********************** Initial Wavefront
wfr = SRWLWfr() #For intensity distribution at fixed photon energy
wfr.allocate(1, 100, 100) #Numbers of points vs Photon Energy, Horizontal and Vertical Positions
wfr.mesh.zStart = 43.7 #Longitudinal Position [m] from Center of Straight Section at which SR has to be calculated
wfr.mesh.eStart = 21747 #Initial Photon Energy [eV]
wfr.mesh.eFin = wfr.mesh.eStart #Final Photon Energy [eV]
wfr.mesh.xStart = -0.0003 #Initial Horizontal Position [m]
wfr.mesh.xFin = 0.0003 #Final Horizontal Position [m]
wfr.mesh.yStart = -0.0005 #-0.001 #Initial Vertical Position [m]
wfr.mesh.yFin = 0.0005 #0.001 #Final Vertical Position [m]
meshInitPartCoh = deepcopy(wfr.mesh)
wfr.partBeam = elecBeam

#***************** Optical Elements and Propagation Parameters

Drift_FrontEnd_M1 = SRWLOptD(51.0 - 43.7) #Drift from Front-End Slits to M1

#read-in mirror slope arror data from file and setup the corresponding "Transmission" type optical element
print('Defining Transmission element (to simulate mirror surface height profile) ... ', end='')
incAngM = 1.e-03 #Grazing Angle [rad]
horApM = 10e-03 #Horizontal Aperture of M1 [m]
verApM = 0.9*incAngM #Vertical Aperture of M1 [m]

OpTrM1 = SRWLOptT(100, 914, horApM, verApM) #M1
OpTrM2 = SRWLOptT(100, 914, horApM, verApM) #M2
heightProfData = AuxReadInDataColumns(os.path.join(os.getcwd(), strDataFolderName, strMirSurfHeightInFileName), 2, '\t', 2)
#TEST: changing sign of the height profile (this may change de-focusing element to a focusing)
for iy in range(len(heightProfData[1])):
    heightProfData[1][iy] *= -1

AuxTransmAddSurfHeightProfile(OpTrM1, heightProfData, 'y', incAngM)
AuxTransmAddSurfHeightProfile(OpTrM2, heightProfData, 'y', incAngM)

if(srwl_uti_proc_is_master()):
    #Saving optical path difference data to file (for viewing/debugging)
    AuxSaveOpTransmData(OpTrM1, 3, os.path.join(os.getcwd(), strDataFolderName, strMirOptPathDifOutFileName))

print('done')

Drift_M1_M2 = SRWLOptD(55.1 - 51.0) ##Drift from M1 to M2

Drift_M2_Obs = SRWLOptD(87.0 - 55.1) ##Drift from M2 to Observation

#Wavefront Propagation Parameters:
#                      [ 0] [1] [2]  [3] [4] [5]  [6]  [7]  [8]  [9] [10] [11] 
ppDrift_FrontEnd_M1 =  [ 0,  0, 1.0,  1,  0, 3.0, 2.0, 2., 10.0,  0,  0,   0]
ppOpTrM1 =             [ 0,  0, 1.0,  0,  0, 1.0, 1.0, 1.0, 1.0,  0,  0,   0]
ppDrift_M1_M2 =        [ 0,  0, 1.0,  1,  0, 1.0, 1.0, 1.0, 1.0,  0,  0,   0]
ppOpTrM2 =             [ 0,  0, 1.0,  0,  0, 1.0, 1.0, 1.0, 1.0,  0,  0,   0]
ppDrift_M2_Obs =       [ 0,  0, 1.0,  1,  0, 1.0, 1.0, 1.0, 1.0,  0,  0,   0]
ppFinal =              [ 0,  0, 1.0,  0,  1, 1.0, 1.0, 1.0, 1.0,  0,  0,   0]

#[ 0]: Auto-Resize (1) or not (0) Before propagation
#[ 1]: Auto-Resize (1) or not (0) After propagation
#[ 2]: Relative Precision for propagation with Auto-Resizing (1. is nominal)
#[ 3]: Allow (1) or not (0) for semi-analytical treatment of the quadratic (leading) phase terms at the propagation
#[ 4]: Do any Resizing on Fourier side, using FFT, (1) or not (0)
#[ 5]: Horizontal Range modification factor at Resizing (1. means no modification)
#[ 6]: Horizontal Resolution modification factor at Resizing
#[ 7]: Vertical Range modification factor at Resizing
#[ 8]: Vertical Resolution modification factor at Resizing
#[ 9]: Type of wavefront Shift before Resizing (not yet implemented)
#[10]: New Horizontal wavefront Center position after Shift (not yet implemented)
#[11]: New Vertical wavefront Center position after Shift (not yet implemented)

#"Beamline" - Container of Optical Elements (together with the corresponding wavefront propagation instructions)
optBL = SRWLOptC([Drift_FrontEnd_M1,   OpTrM1,   Drift_M1_M2,   OpTrM2,   Drift_M2_Obs], 
                 [ppDrift_FrontEnd_M1, ppOpTrM1, ppDrift_M1_M2, ppOpTrM2, ppDrift_M2_Obs, ppFinal]) 

#**********************Calculation (SRWLIB function calls)
if(srwl_uti_proc_is_master()):

    print('Performing electron trajectory calculation and saving data to file (for testing/debugging) ... ', end='')
    partTraj = SRWLPrtTrj()
    partTraj.partInitCond = elecBeam.partStatMom1
    partTraj.allocate(npTraj, True)
    partTraj.ctStart = -0.5*(numPer + 10)*undPer #Start Time for the calculation
    partTraj.ctEnd = 0.5*(numPer + 10)*undPer
    partTraj = srwl.CalcPartTraj(partTraj, magFldCnt, [1])
    AuxSaveTrajData(partTraj, os.path.join(os.getcwd(), strDataFolderName, strTrajOutFileName))
    print('done')

    print('Performing Initial Single-E Electric Field calculation ... ', end='')
    srwl.CalcElecFieldSR(wfr, 0, magFldCnt, arPrecParSpec)
    print('done')
    print('Extracting Intensity from the Calculated Initial Electric Field and Saving it to a file ... ', end='')
    arI = array('f', [0]*wfr.mesh.nx*wfr.mesh.ny) #"flat" array to take 2D intensity data
    srwl.CalcIntFromElecField(arI, wfr, 6, 0, 3, wfr.mesh.eStart, 0, 0)
    srwl_uti_save_intens_ascii(arI, wfr.mesh, os.path.join(os.getcwd(), strDataFolderName, strIntSE_OutFileName))
    print('done')

    print('Simulating Electric Field Wavefront Propagation ... ', end='')
    t0 = time.time();
    srwl.PropagElecField(wfr, optBL)
    print('done; lasted', time.time() - t0, 's')
    print('Extracting Intensity from the Propagated Electric Field and Saving it to a file  ... ', end='')
    arI1 = array('f', [0]*wfr.mesh.nx*wfr.mesh.ny) #"flat" 2D array to take intensity data
    srwl.CalcIntFromElecField(arI1, wfr, 6, 0, 3, wfr.mesh.eStart, 0, 0)
    srwl_uti_save_intens_ascii(arI1, wfr.mesh, os.path.join(os.getcwd(), strDataFolderName, strIntPropSE_OutFileName))
    print('done')

#sys.exit(0) #Uncomment to exit before multi-electron simulations 
    
print('Starting simulation of Partially-Coherent Wavefront Propagation (takes a lot of time)... ')
nMacroElec = 50000 #Total number of Macro-Electrons (Wavefronts)
nMacroElecAvgOneProc = 5 #Number of Macro-Electrons (Wavefronts) to average on each node before sending data to master (for MPI calculations)
nMacroElecSavePer = 10 #Saving periodicity (in terms of Macro-Electrons) for the Resulting Intensity
radStokesProp = srwl_wfr_emit_prop_multi_e(elecBeam, magFldCnt, meshInitPartCoh, 1, 0.01, nMacroElec, nMacroElecAvgOneProc, nMacroElecSavePer, 
                                           os.path.join(os.getcwd(), strDataFolderName, strIntPropME_OutFileName), sampFactNxNyForProp, optBL)
print('done')

