Comments to "SRWLIB" v. 0.05x (November 2011)
================================================

- "srwlpy.pyd", "srwlpy.so" are SRW Python bindings (shared libraries) compiled for 64-bit Windows and Linux respectively; note that 32-bit version for Windows is also available: srw_python/lib/srwlpy_win32.pyd; to use it (with 32-bit Python!) - rename it to "srwlpy.pyd" and place into the main "srw_python" directory in place of the existing "srwlpy.pyd".

NOTE: this SRW Python binding and examples require Python 3.2 or higher; it wouldn't work with lower Python versions.

- "srwlib.py", "SRWLIB_Example*.py" - SRWLIB Python module and example files. 

- "lib/srw*.lib", "lib/libsrw_x86_64.a": static SRW libraries compiled for 32- (srw_win32.lib) and 64-bit (srw_x64.lib) Windows and 64-bit Linux (libsrw_x86_64.a).

- "srwlclient*.exe": 32- (srwlclient32.exe) and 64-bit (srwlclient64.exe) simple test C client application for Windows, illustrating the use of SRWLIB. It runs different examples (essentially the same as "SRWLIB_Example*.py" scripts); the source file is: srw_python/src/srwlclient.cpp.

- srw_python/src/srwlib.h is the header file of SRW C API (it defines some structures and declares functions of SRWLib).

