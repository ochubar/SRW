Comments to "SRWLIB" v. 0.06x (May 2012)
====================================================

Basic content and installation of the SRWLIB package:
----------------------------------------------------

- "srwlpy.pyd", "srwlpy.so" are SRW Python bindings (shared libraries) compiled for Windows and Linux respectively. Note that there is no guarantee that these files are compatible with the versions of operating system and Python that you are using. To make sure that this is the case, copy the appropriate shared library file version from ../srw_python/lib/srwlpy*.pyd (or ../srw_python/lib/srwlpy*.so) to ../srw_python/lib/srwlpy.pyd (or ../srw_python/lib/srwlpy.so). The shared library versions for Python 3.2 and 2.7 and 64- and 32-bit Windows and Linux are available in ../srw_python/lib. The file names are self-explanatory: e.g. "srwlpy3_x64.so" is a version for Python 3.2 for Windows 64-bit; "srwlpy2_i686.so" is for Python 2.7 for Linux 32-bit.

- "srwlib.py" is SRWLIB Python module definition file; it is compatible both with Python 3.2 (or higher) and 2.7 (or higher).

- "SRWLIB_Example*.py" files are example SRWLIB Python scripts, which are also compatible with Python 3.2 and 2.7. 

- "../srw_python/lib/srw*.lib", "../srw_python/lib/libsrw*.a" are static SRW libraries (C API) compiled for 32- (srw_win32.lib) and 64-bit (srw_x64.lib) Windows and 32-bit (libsrw_i686.a) and 64-bit (libsrw_x86_64.a) Linux. These files may not be necessary for the SRWLIB for Python (because *.pyd and *.so files should normally contain them linked).

- "srwlclient*.exe": 32- (srwlclient32.exe) and 64-bit (srwlclient64.exe) simple demo test C client applications for Windows, illustrating the use of SRWLIB. They run some examples (however not all those available in Python); the source file is: ../srw_python/lib/srwlclient.cpp.

- ../srw_python/lib/srwlib.h is the header file of SRW C API (it defines some structures and declares functions of SRWLIB).

Optional configuring of Python and SRWLIB on Linux:
----------------------------------------------------

Make sure that path to Python 3.2 (or 2.7) is added to the PATH variable and "srw_python" directory to PYTHONPATH variable:
export PATH="$PATH:<absolute path to Python 3.2>" #this is not necessary if you install python using the distro's package manager
export PYTHONPATH="$PYTHONPATH:SRW_Dev/work/srw_python/" #temporarely solution
	or:
echo "export PYTHONPATH=$PYTHONPATH:SRW_Dev/work/srw_python/" >> ~/.bashrc # permanent solution for a single user
Setting up PYTHONPATH allows to import srwlpy module from any directory.
To run examples:
cd ../srw_python
python3 SRWLIB_ExampleXX.py

